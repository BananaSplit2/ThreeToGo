var searchData=
[
  ['col',['col',['../structcaseg.html#afb52e720f5f0c483db5861f9e42e924e',1,'caseg']]],
  ['color',['color',['../structtoken.html#a0fd02fb9277ffcb35a75066ffe95e8c7',1,'token']]],
  ['combo',['combo',['../structgame.html#a4cb3fe817072bbf8f876295d34726aed',1,'game']]]
];
