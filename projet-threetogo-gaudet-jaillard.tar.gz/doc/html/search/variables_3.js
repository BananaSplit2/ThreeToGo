var searchData=
[
  ['previous_5fcolor',['previous_color',['../structtoken.html#a9ac6870b481ad57ca4db22b60ae46219',1,'token']]],
  ['previous_5fshape',['previous_shape',['../structtoken.html#ad16851081c8254e19ecb6b2deaae5cb0',1,'token']]]
];
