var searchData=
[
  ['nb_5ftokens',['nb_tokens',['../structgame.html#af524b834302ca6ab20dbb042104cd330',1,'game']]],
  ['next',['next',['../structtoken.html#a7b69b155a444c7abd1564cc0c4f4506f',1,'token']]],
  ['next_5fcolor',['next_color',['../structtoken.html#a2956d386596bcb55e1b8e91006c12e7a',1,'token']]],
  ['next_5fshape',['next_shape',['../structtoken.html#a80b69bcd24a8563a89369431e21519c4',1,'token']]]
];
