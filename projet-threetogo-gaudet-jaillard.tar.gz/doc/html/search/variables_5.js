var searchData=
[
  ['score',['score',['../structgame.html#aef160b7437d94056f1dc59646cd5b87d',1,'game']]],
  ['shape',['shape',['../structtoken.html#ab1a7e6f9587f8a51986ea12e6c121fa3',1,'token']]],
  ['size',['size',['../structsequence.html#a439227feff9d7f55384e8780cfc2eb82',1,'sequence']]],
  ['start',['start',['../structsequence.html#ab5d5b1277dee91b9b524b62df22ae1c5',1,'sequence']]]
];
