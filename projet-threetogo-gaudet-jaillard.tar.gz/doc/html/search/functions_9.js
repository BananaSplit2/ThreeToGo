var searchData=
[
  ['next_5fcolor',['next_color',['../token_8h.html#a9e140295ada7471f8a115c8a03a3d398',1,'token.c']]],
  ['next_5fshape',['next_shape',['../token_8h.html#a1524a49d0af2872e4147ce4dad043bb4',1,'token.c']]]
];
