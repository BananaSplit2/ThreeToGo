var searchData=
[
  ['lig',['lig',['../structcaseg.html#a90c51449aa3fa2171db5fc1fa097856f',1,'caseg']]],
  ['lst_5ftokens',['lst_tokens',['../structgame.html#a4fd58bea0558ade00f7961f595dcd051',1,'game']]]
];
