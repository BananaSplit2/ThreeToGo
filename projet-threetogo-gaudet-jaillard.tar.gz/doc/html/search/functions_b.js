var searchData=
[
  ['read_5fhigh_5fscores',['read_high_scores',['../fileio_8h.html#a4abc4c0dd857e42b48bb776ada3b8568',1,'fileio.c']]],
  ['refresh_5fscreen',['refresh_screen',['../graphique_8h.html#a1574493538802abc3ef01b720fca67ed',1,'graphique.c']]]
];
