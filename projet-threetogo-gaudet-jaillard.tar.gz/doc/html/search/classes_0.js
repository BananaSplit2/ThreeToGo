var searchData=
[
  ['caseg',['caseg',['../structcaseg.html',1,'']]]
];
